## File: templates/LEARNER_PROFILE.md

# Portable learner profile
- Profile schema version: 1
- Profile namespace/label (non-identifying):
- Storage location or platform workspace (never a public registry):
- Persistent tracking opt-in date:
- Last updated (UTC or timezone-labeled):
- Last saved / last reconciled session ID:
- Profile date:
- Experience level (as stated):
- Learning goal:
- Specialty focus/intensity:
- Difficulty mode / manual tier:
- Exam framework:
- Setting:
- Guideline/jurisdiction preference:
- Learning mode:
- Competency themes supported by completed cases:
- Exposure summary and untested areas:
- Coaching support used:
- Next practice goals:

Update this file automatically after each completed case when the learner opted in and the host platform supports user-scoped writes. Keep session-by-session detail in `sessions/` and IDs in `SESSIONS_INDEX.md`; this file is the concise cumulative profile. Reconcile from saved sessions to avoid duplicate counts. If this file is being used as a portable fallback, the learner may bring the latest copy into a future chat.

Non-identifying and learner-controlled. Pasted summaries are user-supplied context, not verified credentials or complete history.



---

## File: templates/PROFILE_INDEX.md

# Learner profile index

For Google Drive, use a Google Sheet titled `PROFILE_INDEX` with these columns:

| Profile key | Profile record path/link | Created | Last updated | Status |
|---|---|---|---|---|

For a local workspace, this table may be saved as `PROFILE_INDEX.md`. Use non-identifying profile keys. Do not store names, contact information, credentials, or clinical-patient data here. Before selecting a profile, confirm it belongs to the active learner; ask if ambiguous.


---

## File: templates/PROGRESS_REVIEW.md

# Progress and exposure review
- Review date / cases included:
- Learning goals:
- Comparable case/rubric evidence? Explain:
- Competency themes and evidence:
- Safety events/remediation:
- Hint support and independent retention:
- Exposure by domain, setting, age group and acuity:
- User-directed vs automatic cases:
- Under-sampled areas:
- Learner reflection:
- Next practice plan and review date:

Avoid false precision in small samples. Exposure is what was sampled; competency is observed performance. Neither is credentialing evidence.



---

## File: templates/SESSIONS_INDEX.md

# Session index

Schema version: 1  
Last updated (UTC or timezone-labeled):

One row for each saved session record. The session ID is the deduplication key; do not add the same ID twice. For Google Drive, this table is a Google Sheet with the same column names.

| Session ID | Record path | Status | Case domain | Date |
|---|---|---|---|---|

At the end of a session, check this index before writing. If the ID already exists, update the matching record and row. Recalculate cumulative exposure from indexed records when correcting or deleting history. When records are changed, update the last-updated time.


---

## File: templates/SESSION_RECORD.md

# Session record
- Non-identifying session ID / start timestamp with timezone (see persistence guide):
- Completion status (completed / incomplete / reliability-excluded):
- Platform/model (optional):
- Mode, learner level, setting, guideline framework:
- Case ID / domain / presentation / acuity / tier:
- Case user-directed or automatic:
- Learning objectives:
- Stages completed:
- Hint support:
- Case reveal / reasoning summary:

| Domain | Score/status | Evidence |
|---|---|---|
| History | | |
| Examination | | |
| Investigations | | |
| Assessment | | |
| Management/reassessment | | |
| Communication/follow-up | | |

- Separate safety classification and event rationale:
- Strengths:
- Priority improvement:
- Self-correction:
- Guideline/local verification needed:
- Next goal:
No patient identifiers. Formative only.

Save one copy per session under the active learner's private `sessions/` folder when supported. Add its ID to `SESSIONS_INDEX.md`, then update that learner's cumulative profile and progress review. If a retry finds the same ID, update that record rather than adding a duplicate. Never put these records in the shared skill installation folder.



---

## File: templates/STORE_MANIFEST.md

# Clinical Encounter Simulator profile store

Store marker: `clinical-encounter-simulator-profile-store-v1`
Schema version: 1
Package version initialized with:
Created (UTC or timezone-labeled):
Last updated (UTC or timezone-labeled):

This marker identifies the dedicated learner-record store. It contains educational practice preferences and progress only. Do not add real patient information, credentials, or access tokens. Keep the folder private to its learner unless they explicitly choose otherwise.

For Google Drive, save this content as a Google Doc titled `CES_STORE_MANIFEST` at the root of `Clinical Encounter Simulator - Profile Store`. For local files, keep it as `STORE_MANIFEST.md`.
