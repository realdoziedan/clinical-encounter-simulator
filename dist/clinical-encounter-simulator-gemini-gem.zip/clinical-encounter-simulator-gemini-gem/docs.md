## File: docs/ONBOARDING.md

# Onboarding
A genuinely new learner begins with brief onboarding unless they supply an existing profile or explicitly say skip setup/use defaults and start. First check for a profile in the platform's private user-scoped store. If found, load it and continue without onboarding. Otherwise give a brief orientation and collect: experience level, learning objective, focus/exam, adaptive or manual tier, setting/guideline preference, and assessment/coaching/challenge mode. Offer the full guide, but do not require reading it before starting. Ask whether the learner opts in to persistent progress tracking; explain the record types and storage location. For Google Drive, explain that opt-in authorizes searching the connected Drive for the marked simulator store and creating the dedicated store/profile files if none exists. If more than one learner can use the workspace, ask for a non-identifying profile label. Avoid re-asking information already supplied. Do not request patient details or Google credentials.

Defaults: background unspecified; broad clinical development; balanced mix; adaptive Tier 3; no exam focus; varied setting; current evidence with local assumptions stated; assessment mode; full encounter. Confirm the summary and proceed on clear acceptance/instruction. Do not repeat onboarding in the same conversation.

When the learner opts in and private write-capable storage is available, search/reuse or create the store as described in `PLATFORM_ADAPTERS.md`, then create a learner profile, session folder/index, and progress file. Verify each saved change. If the Drive connector is not connected, guide the learner to connect it in the platform UI; do not handle credentials or OAuth codes. If storage is unavailable, say what the platform can and cannot retain and offer an updated portable profile. Never claim cross-chat history that is not supplied. Full workflow: `../references/PROFILE_PERSISTENCE.md` and `PLATFORM_ADAPTERS.md`.



---

## File: docs/USER_GUIDE.md

# User guide

## How to start
Tell the simulator your level, goal, focus/exam, difficulty, setting/guideline, and preferred mode—or say “Use recommended defaults and start.” You can request a specific case directly. The assistant gives a brief orientation and confirms preferences, then presents a fictional patient opening. Ask for this full guide whenever useful.

## During the case
Ask questions naturally. Request examinations and investigations. State your assessment and management; reassess when the patient’s condition changes. You may ask for a hint in Coaching mode, pause, skip stages, end early, or request a retry. In the full encounter, stages run history, examination, investigations, assessment, management, counselling/follow-up, then debrief.

## After the case
Give your own leading diagnosis before the reveal. Review the staged feedback, scoring evidence, separate safety classification, guideline caveats and next learning goal. Ask for the full debrief or a specific stage audit. If you opted into progress tracking and the platform supports private persistent writing, the assistant should save the session and update your progress automatically. Otherwise it should explain the limitation and provide a portable updated record.

## Example commands
“Use defaults and start”; “Focus on paediatrics, strong focus”; “Manual difficulty, Tier 2”; “Prepare me for MRCP”; “History only”; “Coaching mode”; “Show my exposure profile”; “Create a portable learner profile”; “Pause”; “End case”; “Full debrief.”

Use fictional information only. Do not enter live patient data. Simulator scores are not credentialing evidence.



---

## File: docs/PLATFORM_ADAPTERS.md

# Platform setup and storage adapters

This page prevents the skill from promising one platform's persistence behavior on another. Platform interfaces and plan limits change; last reviewed 2026-11-24. Check the linked official documentation and the actual tools available in the learner's session before claiming a capability.

## Capability check

Before offering automatic records, check all of these for the current account/workspace:

1. **Read:** can the assistant retrieve the saved learner profile in a later session?
2. **Write:** can the assistant create and update learner-owned records, not only produce a downloadable answer?
3. **Persistence:** do changes survive the chat and remain available to the same learner in later sessions?
4. **Scope:** is storage private to the learner or explicitly isolated by a private project/workspace?
5. **Control:** can the learner inspect, correct, export, and delete records?

Only promise full automatic tracking when all five are established. If any item is absent or unclear, treat the surface as read-only and use the portable handoff in `../references/PROFILE_PERSISTENCE.md`.

## Adapter guide

| Platform surface | Suitable role | Do not assume |
|---|---|---|
| **OpenClaw skill with a private writable agent workspace** | Best fit for the full file workflow. Load companion references from the skill directory; write learner records in a separate private workspace folder, never inside the installed skill. Confirm the agent actually has file read/write tools and that its workspace persists. | ClawHub installation alone does not provide profile storage or grant file tools. A workspace shared by agents is not automatically a per-user store. |
| **Google Drive folder (shared source of truth)** | Recommended cross-platform option when each AI account is separately connected to the same private Drive folder and has verified access to create/read/update the required Docs, Sheets, and files. Use the canonical layout below. | “Sync” is not identical across platforms. Some actions need confirmation; product availability and write scopes vary. A Drive link added as a ChatGPT Project source is not pre-synced for retrieval. Never claim a saved change until read-back verifies it. |
| **ChatGPT Project** | Project instructions, files, and project chat context can provide continuity. A connected Google Drive app may search/read and, where enabled, update source files. Use the Drive connector directly in project chats for the canonical records. | Project memory is not a complete, auditable session ledger. Google Drive app availability depends on plan/workspace permissions. Drive links added as project sources do not sync in advance. Do not assume attached files can be rewritten. |
| **Claude Project** | Project instructions and knowledge files provide reusable context. Claude's Google Workspace connectors can read Drive and support creating/saving or editing Docs/Sheets/Slides in supported surfaces. Use the connector to update the same canonical Drive records. | Project knowledge read access alone is not write access. Connector actions may request approval; editing shared files may require explicit review/confirmation. |
| **Gemini Gem** | Gem instructions and knowledge files provide a reusable setup. Connected Google Workspace features can search/read Drive and write/edit Docs or manage files where enabled. Use the same canonical Drive records. | A Gem or attached knowledge source is not itself a profile-writing system. Workspace/account eligibility and confirmation prompts apply. Google's Gems-to-skills rollout may change the Gem setup flow. |
| **Other assistants** | Load the Markdown core and any linked references; use the platform's supported private project or workspace if it passes the capability check. | Markdown compatibility does not guarantee skill discovery, write access, memory, or cross-platform profile sync. |

## Recommended shared Drive layout

At onboarding, offer one-time storage choices: platform-private storage, a private Google Drive folder, local files if the agent can access them, or no persistent tracking. For Drive, tell the learner that after they opt in, the assistant will search their connected My Drive for this simulator's marked store and reuse it; if none exists, it will create the store and initialize one profile. This consent covers searching and creating only the dedicated simulator folder and its profile records. Each platform still requires its own Google account connection and may require action confirmations. Do not request credentials or OAuth codes in chat. If the connector cannot search but can open/write by direct link, ask once for the folder link; if it cannot create/write, use the portable fallback.

### Search, reuse, or create

1. Search the connected account's My Drive for a `CES_STORE_MANIFEST` file with the expected schema marker. This marker distinguishes the simulator store from unrelated folders with similar names.
2. If exactly one valid manifest exists, read it and its profile index, then reuse the matching learner profile. If one store contains a single profile, use it without asking the learner to choose. If there are several profiles, ask which profile they own/use.
3. If no valid manifest exists, search for the exact folder `Clinical Encounter Simulator - Profile Store`. Reuse it only if it is empty or already has the simulator's expected `profiles/` layout. Do not adopt a folder with unrelated contents.
4. If no suitable folder exists, create `My Drive/Clinical Encounter Simulator - Profile Store/`, then the `profiles/default/` and `profiles/default/sessions/` folders. Add the manifest, profile-index Sheet, profile Doc, progress Doc, and session-index Sheet from the templates. Use a non-identifying profile key; create one default profile unless the learner explicitly says the Drive folder is shared by multiple learners.
5. If multiple candidate stores exist, a candidate has unexpected contents, or the folder's sharing status cannot be checked and the learner needs private storage, stop and ask a short clarifying question. Do not guess or change sharing permissions.
6. Read back the manifest, profile index, and initialized profile/session index. Confirm the setup only after successful verification.

The one-time opt-in must state that the assistant will search the connected Drive and create the dedicated store if needed. Platform-mandated OAuth or per-action confirmations still apply; never bypass them. Once setup succeeds, update files after completed practice without another setup question, subject to any platform-required approval prompt.

Use Google Docs/Sheets as the common editable formats rather than assuming every connector can update `.md` files:

```text
My Drive/Clinical Encounter Simulator - Profile Store/
  CES_STORE_MANIFEST (Google Doc)
  PROFILE_INDEX (Google Sheet)
  profiles/<profile-key>/
    LEARNER_PROFILE (Google Doc)
    PROGRESS_REVIEW (Google Doc)
    SESSIONS_INDEX (Google Sheet)
    sessions/
      <session-id> (Google Doc)
```

Keep the folder private to the learner. If multiple people share it, use separate profile subfolders and resolve the active profile before any read or write. Include a `last_updated` timestamp and schema version in the profile and index. For concurrent sessions, read the latest revision just before writing; if it changed since it was loaded, re-read and merge or pause for the learner rather than silently overwriting another update. Session IDs remain the deduplication key.

In ChatGPT, do not rely on pre-sync from a Drive folder link added as a Project source; use the connected Drive app in the conversation to retrieve the current record. If Drive is unavailable for the account, use a private writable platform workspace or the portable fallback.

## Record locations

For a writable OpenClaw-style workspace, use this layout outside the installed skill directory:

```text
<private-agent-workspace>/clinical-encounter-simulator/
  STORE_MANIFEST.md
  PROFILE_INDEX.md
  profiles/<profile-key>/
    LEARNER_PROFILE.md
    PROGRESS_REVIEW.md
    SESSIONS_INDEX.md
    sessions/<session-id>.md
```

Use the platform's equivalent private project or workspace scope elsewhere. A profile key should be a short, non-identifying label. If the host identity already isolates one learner, use a neutral key such as `default`; do not ask for a second label unnecessarily.

## Official references

- [OpenClaw skills and companion references](https://docs.openclaw.ai/tools/skills)
- [ChatGPT Projects](https://help.openai.com/en/articles/10169521-using-projects-in-chatgpt), [Google Drive app and setup](https://help.openai.com/en/articles/10929079-google-drive-app-and-setup-in-chatgpt), and [Drive access controls](https://help.openai.com/en/articles/20001608-managing-google-drive-access-in-chatgpt)
- [Claude Projects](https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects) and [Google Workspace connectors](https://support.claude.com/en/articles/10166901-use-google-workspace-connectors)
- [Gemini Gems](https://support.google.com/gemini/answer/15146780?co=GENIE.Platform%3DDesktop) and [Gemini tasks and Workspace actions](https://support.google.com/gemini/answer/17094507?co=GENIE.Platform%3DDesktop&hl=en)

These links describe platform features, not guarantees that the simulator can write user records. Re-check before release and label any observed capability with the account, plan, date, and test evidence.


---

## File: docs/PORTABILITY.md

# Platform portability

The simulation core is Markdown, but platform support for discovering companion files, retaining history, and writing learner records differs. Read `PLATFORM_ADAPTERS.md` before claiming persistent automation.

Progress tracking is opt-in. After opt-in, initialize and update records automatically only if the current platform has verified private read/write storage that persists across chats. A project or Gem with attached knowledge may provide reusable reference context without providing writeback. If support is missing or unclear, use the portable profile handoff and state the limit. Profiles do not sync across platforms.

Keep profiles separate from the published skill and from shared instructions. The optional integrity checker is for package maintainers, not required to run cases. For guidance verification, use a reliable current source when available; otherwise label time-sensitive content unverified and omit unsafe specifics.


---

## File: docs/VERSIONING_AND_MAINTENANCE.md

# Versioning and maintenance
Use semantic versions: major for incompatible behavior/structure; minor for backward-compatible capability; patch for corrections.

For changes, log rationale, files, clinical/safety impact, reviewer and date. Review clinical content with a qualified educator using current local guidance. Update manual fixtures and paths, run the integrity checker, manually review affected flows, compare preserved source hash, inspect ZIP listing, and record release. Before any public release, confirm the right to redistribute every included source file and inspect the preserved master and package for private, identifying, confidential, or otherwise unintended content. Source preservation does not itself grant redistribution rights.

## Unreleased
Added a Gemini Gem kit (`dist/clinical-encounter-simulator-gemini-gem.zip`): nine Gemini-supported files that keep the package structure within Gemini's 10-file limit, with setup instructions. `scripts/build_gemini_kit.py` builds it and the GitHub Action rebuilds it with the single file. Skill content is unchanged. The Gem instructions include the full SKILL.md, unchanged, because Gems apply Instructions on every turn but only look up Knowledge files as needed.

## 1.6.0 — 2026-11-25
Changed the license from MIT to CC BY-NC 4.0 for this and later versions; earlier versions keep the MIT License. Rewrote the skill description in SKILL.md frontmatter to emphasise medical education, board exam preparation, and real-life clinical encounters, and to say when to use the skill. README now opens with what the simulator does and sample prompts. No clinical or safety content changed.

## 1.5.1 — 2026-11-25
Moved the version in SKILL.md frontmatter under `metadata:`. Claude's skill upload rejects a top-level `version` key, so the 1.5.0 package could not be installed there. No clinical or safety content changed.

## 1.5.0 — 2026-11-25
Added a single-file edition (`dist/clinical-encounter-simulator-single.md`) for platforms that accept only one skill file. It bundles SKILL.md with the runtime references, docs (including this changelog), and templates, unchanged. Added `scripts/build_single_file.py` to regenerate it and a GitHub Action that reruns the integrity checker and rebuilds the single file on pushes to main. Fixed the Python integrity checker, which reported README links to folders (`references/`, `docs/`, `templates/`, `tests/`, `source-masters/`) as broken. No clinical or safety content changed.

## 1.4.2 — 2026-11-24
Added the MIT license and practical sharing, installation, prompt-based setup, and contribution guidance. Clarified that prompt-based installation depends on the agent's platform and available tools.

## 1.4.1 — 2026-11-24
Aligned the Python and Node integrity checker file inventories and documented both commands, preventing the Python check from overlooking the newer platform and Drive-store files. Made the persistent-record opt-in condition explicit in the main skill workflow so it cannot be read as permission to track users who declined.

## 1.4.0 — 2026-11-24
Added seamless Drive bootstrap: after explicit opt-in, search for a marked simulator store, reuse a unique valid store, or create the dedicated folder and initialize the manifest, profile index, learner profile, progress review, and session index. Added collision/ambiguity handling and setup verification requirements.

## 1.3.0 — 2026-11-24
Added Google Drive as a shared-storage adapter across ChatGPT, Claude, and Gemini when each platform is separately authorized and read/write actions are verified. Standardized shared records on Google Docs and Sheets; documented confirmation prompts, ChatGPT Project-source sync limits, concurrent-edit handling, and cross-platform round-trip tests.

## 1.2.0 — 2026-11-24
Made learner tracking explicitly opt-in; added platform adapter guidance and capability checks; defined a private workspace layout and duplicate-resistant session index/IDs; softened first-use guide burden; aligned user guide with automatic-save behavior; added privacy/control wording; clarified narrative-only scoring when numeric anchors are unavailable; added a safe fallback for unverifiable time-sensitive clinical guidance; documented a public-release content/rights review gate.

## 1.1.0 — 2026-11-24
Added one-time learner setup and automated per-user profile/session/progress persistence when the host platform provides private persistent storage and write tools. Added explicit boundaries for shared workspaces, duplicate-safe session updates, verification, privacy, and portable fallback when file writes are unavailable. The package does not provide cross-platform synchronization or hosted storage.

## 1.0.0 — 2026-11-23
Initial modular package from Library master; untouched source included. Adapted the core into portable files while retaining master as full reference.
Review before institutional deployment and at least annually, or after material guideline/platform changes. Label local adaptations with owner and date.

